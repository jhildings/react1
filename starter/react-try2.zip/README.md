# MyReads Project

 This is the first project in the Udacity Nanodegree for React

 To install the required modules, run 

     npm install 

To run the project, run 

    npm start 

Then open the page http://localhost:3000/ in your local browser